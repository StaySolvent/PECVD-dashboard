# -*- coding: utf-8 -*-
"""
Project3 : PECVD 가상 계측(VM) 및 이상 감지(FDC) - 서비스(백엔드) 모듈
  app3.py(Streamlit 대시보드)가 이 파일의 함수를 import 해서 사용한다.

  load_csv        : 데이터 로드 + 파생변수 + 3σ 양/불 라벨링
  hist_pro        : 수치형 변수 히스토그램 (3σ 벗어난 값 있으면 제목 빨간색)
  line_pro        : 수치형 변수 Trend(line) chart + UCL/LCL
  corr_pro        : target 과의 상관계수 순으로 정렬한 히트맵
  binary_model    : 분류 모델(FDC) 비교 → 최고 모델 model/binary_{target}.pkl 저장
  binary_predict  : 저장된 분류 모델로 전체 웨이퍼 양/불 판정
  linear_model    : 회귀 모델(VM) 비교 → 최고 모델 model/linear_{target}.pkl 저장
  linear_predict  : 저장된 회귀 모델 예측값과 실제값의 잔차가 ±σ 벗어나면 이상치
  vm_predict      : 저장된 회귀 모델로 예측값만 반환 (실시간 FDC 화면에서 사용)

  [수정] 표시가 원본 수업 코드에서 고친 부분
"""

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib
import warnings
import os
import matplotlib.font_manager as fm
warnings.filterwarnings('ignore')

#  pip install scikit-learn xgboost lightgbm seaborn streamlit

# [수정] xgboost / lightgbm 이 설치 안 된 PC 에서도 나머지 모델로 동작하도록
try:
    from xgboost import XGBClassifier, XGBRegressor
    HAS_XGB = True
except ImportError:
    HAS_XGB = False
try:
    from lightgbm import LGBMClassifier, LGBMRegressor
    HAS_LGBM = True
except ImportError:
    HAS_LGBM = False

# Streamlit Cloud(Linux) 환경 나눔고딕 폰트 파일 경로
nanum_path = '/usr/share/fonts/truetype/nanum/NanumGothic.ttf'
if os.path.exists(nanum_path):
    fm.fontManager.addfont(nanum_path)          # 1. 서버(Linux) 환경
    plt.rc('font', family='NanumGothic')
else:
    try:
        plt.rc('font', family='Malgun Gothic')  # 2. Windows
    except Exception:
        plt.rc('font', family='AppleGothic')    #    Mac
plt.rcParams['axes.unicode_minus'] = False

# [수정] 이 파일 위치 기준으로 data / model 폴더 경로 고정 (실행 위치가 달라도 동작)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "data", "semi_process_data2.csv")
MODEL_DIR = os.path.join(BASE_DIR, "model")
os.makedirs(MODEL_DIR, exist_ok=True)           # [수정] model 폴더 없으면 joblib.dump 에러 → 자동 생성

# ---------------------------------------------------------------
# [수정] feature 에서 제외할 컬럼 정의 (데이터 누수 방지)
# ---------------------------------------------------------------
# 공정 후 계측값(미래 정보) : EDGE CENTER 도 POST 계측이므로 제외해야 함 (원본에서 누락)
LEAK_COLS = ['POST THK AVG', 'POST PC', 'EDGE CENTER']
# 식별자/시간 : 공정 물리량이 아님
ID_COLS = ['LOT', 'WF', 'TKIN time']
# 파생변수/라벨
DERIVED_COLS = ['Depo_THK', 'Particle', 'Depo_THK_y', 'Particle_y']
# 범주형 → 원-핫 인코딩해서 사용 (원본은 select_dtypes 로 버려졌음)
CAT_COLS = ['Chamber', 'Precursor']


def make_features(df, feature_cols=None):
    """[수정] 학습/예측 공통 feature 생성 함수
       feature_cols 를 주면(예측 시) 학습 때와 같은 컬럼 순서로 맞춘다."""
    X = df.drop(columns=[c for c in LEAK_COLS + ID_COLS + DERIVED_COLS if c in df.columns])
    X = pd.get_dummies(X, columns=[c for c in CAT_COLS if c in X.columns], dtype=int)
    X = X.select_dtypes(include='number')
    if feature_cols is not None:
        X = X.reindex(columns=feature_cols, fill_value=0)
    return X


# %%
def load_csv(CSV_PATH=DATA_PATH):

    df = pd.read_csv(CSV_PATH, encoding="utf-8")
    #1. 결측치 / 단일값 컬럼 삭제 (Chuck Edge temp 삭제됨)
    df = df.dropna(axis=1)
    df = df.drop(columns=[c for c in df.columns if df[c].nunique() <= 1])

    #2. Depo_THK, Particle 추가
    df['Depo_THK'] = df['POST THK AVG'] - df['PRE THK AVG']
    df['Particle'] = df['POST PC'] - df['PRE PC']
    df['Particle'] = df['Particle'].clip(lower=0)    # 0 을 최하한선으로 고정

    #3. 평균 ± 3σ 벗어나면 불량
    def labeling_pro(target):
        mean_val = df[target].mean()
        std_val = df[target].std()
        lower_limit = mean_val - 3 * std_val
        upper_limit = mean_val + 3 * std_val
        y = np.where((df[target] < lower_limit) |
                     (df[target] > upper_limit), 1, 0)
        # 우량=0(Negative), 불량=1(Positive)
        return y

    df['Depo_THK_y'] = labeling_pro('Depo_THK')
    df['Particle_y'] = labeling_pro('Particle')

    return df

'''
df_all=load_csv()
'''

# %%
def hist_pro(df_number):
    wid = 3
    heig = len(df_number.columns) // wid + 1
    fig, axes = plt.subplots(heig, wid, figsize=(10, 20))
    count = 1

    for col in df_number.columns:
        t_mean = df_number[col].mean()
        t_ucl = t_mean + (3 * df_number[col].std())
        t_lcl = t_mean - (3 * df_number[col].std())
        if ((df_number[col].max() > t_ucl) |
            (df_number[col].min() < t_lcl)):
            titlecolor = 'red'
            titlename = col + ': 이상치 확인'
        else:
            titlecolor = 'black'
            titlename = col

        plt.subplot(heig, wid, count)
        count += 1
        plt.title(titlename, fontsize=8, color=titlecolor)
        plt.hist(df_number[col], color='skyblue', edgecolor='black')
        plt.axvline(t_mean, color='red', linestyle='--', linewidth=1, label='Mean')
        plt.axvline(t_ucl, color='orange', linestyle=':', linewidth=1, label='UCL')
        plt.axvline(t_lcl, color='orange', linestyle=':', linewidth=1, label='LCL')

    for ax in axes.flat[count - 1:]:      # [수정] 남는 빈 칸 숨기기
        ax.axis('off')
    plt.tight_layout()
    return fig


def line_pro(df_number):
    wid = 3
    heig = len(df_number.columns) // wid + 1
    fig, axes = plt.subplots(heig, wid, figsize=(10, 20))
    count = 1
    for col in df_number.columns:
        t_mean = df_number[col].mean()
        t_ucl = t_mean + (3 * df_number[col].std())
        t_lcl = t_mean - (3 * df_number[col].std())
        if ((df_number[col].max() > t_ucl) |
            (df_number[col].min() < t_lcl)):
            titlecolor = 'red'
            titlename = col + ': 이상치 확인'
        else:
            titlecolor = 'black'
            titlename = col

        plt.subplot(heig, wid, count)
        count += 1
        plt.title(titlename, fontsize=8, color=titlecolor)
        plt.plot(range(len(df_number[col])), df_number[col])
        plt.axhline(y=t_ucl, color='r', linestyle='dashed')
        plt.axhline(y=t_lcl, color='r', linestyle='dashed')

    for ax in axes.flat[count - 1:]:      # [수정] 남는 빈 칸 숨기기
        ax.axis('off')
    plt.tight_layout()
    return fig

'''
line_pro(df_all.select_dtypes('number'))
'''

# %%
def corr_pro(df, target):
    fig, ax = plt.subplots(2, 1, figsize=(10, 20))
    tdf = df[df.columns[3:-2]].select_dtypes(include='number')   # LOT/WF/TKIN, 라벨 제외

    corr_matrix = tdf.corr()[target].abs()
    sorted_cols = corr_matrix.sort_values(ascending=False).index

    sns.heatmap(df[sorted_cols].corr(),
                annot=True, fmt=".2f", cmap='YlGnBu',
                ax=ax[0], linewidths=0.5, cbar_kws={"shrink": .8})
    # [수정] plt.title 은 ax[1] 에 붙어 덮어써졌음 → ax[0] 에 직접 지정
    ax[0].set_title(f"공정 변수 간 상관관계 히트맵 (정렬 기준: {target})", fontsize=15, pad=20)

    ax[1].plot(range(len(df)), tdf['Particle'], label='Particle')
    ax[1].plot(range(len(df)), tdf['Depo_THK'], label='Depo_THK')
    ax[1].set_title('Particle and Depo_THK')
    ax[1].legend()
    plt.tight_layout()
    return fig, sorted_cols[1:]   # 맨 앞의 target 컬럼은 제외

'''
corr_pro(df_all, 'Depo_THK')
'''

# %%
def binary_model(df, target):
    y = df[target + "_y"]
    # [수정] 불량 가중치를 32 고정 대신 실제 비율(양품수/불량수)로 계산 → Depo 29, Particle 34
    pos_w = round((y == 0).sum() / (y == 1).sum())
    cw = {0: 1, 1: pos_w}                     # 0: 양품(약 97%), 1: 불량(약 3%)

    models = {
        # 1. 선형 및 확률 기반 모델
        "LogisticRegression": LogisticRegression(max_iter=1000, C=0.5,
                                                 class_weight=cw, random_state=42),
        # 2. 거리 기반 모델
        "KNN": KNeighborsClassifier(),
        # 3. 앙상블 (배깅)
        "RandomForestClassifier": RandomForestClassifier(n_estimators=100,
                                                         class_weight=cw, random_state=42),
    }
    # 4. 앙상블 (부스팅) - 실무에서 가장 많이 쓰임
    if HAS_XGB:
        models["XGBoost"] = XGBClassifier(scale_pos_weight=pos_w, eval_metric='logloss',
                                          random_state=42)
    if HAS_LGBM:
        models["LightGBM"] = LGBMClassifier(class_weight=cw, random_state=42, verbosity=-1,
                                            n_estimators=100, learning_rate=0.05,
                                            num_leaves=15, min_child_samples=10,
                                            importance_type='gain')

    anormal = np.sum(y == 1)
    print("\n--- 라벨링 결과 요약 ---")
    print(anormal, (anormal / len(df) * 100), '%')

    # [수정] 누수 컬럼(EDGE CENTER 포함)·식별자 제거 + Chamber/Precursor 원-핫
    X = make_features(df)
    feature_cols = X.columns.tolist()
    print(feature_cols)

    # 1. 데이터 분할 (stratify=y : 양/불 비율 동일하게)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y)

    # 2. 정규화 (Train 으로만 fit)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    print("실제 Test 데이터의 정상/불량 개수:", pd.Series(y_test).value_counts().to_dict())

    results = []
    for name, model in models.items():
        model.fit(X_train_scaled, y_train)
        y_pred = model.predict(X_test_scaled)
        results.append({
            "Model명": name, "model": model, "scaler": scaler,
            "Accuracy": accuracy_score(y_test, y_pred),
            "Precision": precision_score(y_test, y_pred, zero_division=0),
            "Recall": recall_score(y_test, y_pred),
            "F1-Score": f1_score(y_test, y_pred),   # Precision 과 Recall 의 조화평균
            "y_pred": y_pred,
            "feature_cols": feature_cols})
        print(name, '예측불량', np.sum(y_pred == 1), '실제 불량', np.sum(y_test == 1))

    # [수정] F1 동점이면 Recall(불량 놓치지 않기) 높은 모델 우선
    df_results = pd.DataFrame(results).sort_values(by=['F1-Score', 'Recall'], ascending=False)
    df_results = df_results.reset_index(drop=True)
    print(df_results[['Model명', 'Accuracy', 'Precision', 'Recall', 'F1-Score']])

    n = len(df_results)
    fig = plt.figure(figsize=(10, 5 * n))
    count = 1
    for row in range(n):
        t_pred = df_results.loc[row]['y_pred']
        t_name = df_results.loc[row]['Model명']

        plt.subplot(n, 2, count)
        cm = confusion_matrix(y_test, t_pred, labels=[0, 1])
        # [수정] 라벨 반대로 되어 있었음 (0 = 정상, 1 = 불량)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                    xticklabels=['Normal (0)', 'Fault (1)'],
                    yticklabels=['Normal (0)', 'Fault (1)'])
        plt.title('Confusion Matrix:' + t_name)
        plt.xlabel('Predicted')
        plt.ylabel('Actual')

        plt.subplot(n, 2, count + 1)
        plt.hist(x=y_test, alpha=0.5, color='b',
                 label="실제" + str(np.sum(y_test == 0)) + "/" + str(np.sum(y_test == 1)))
        # [수정] 마지막 모델의 y_pred 가 아니라 해당 모델의 t_pred 를 그려야 함
        plt.hist(x=t_pred + 0.25, alpha=0.5, color='r',
                 label="예측" + str(np.sum(t_pred == 0)) + "/" + str(np.sum(t_pred == 1)))
        plt.xlabel('0: 정상 / 1: 불량')
        plt.ylabel('웨이퍼 수')
        plt.title(t_name)
        plt.legend()
        plt.grid(True)
        count += 2
    plt.tight_layout()

    # 최고 모델 파일로 저장
    setmodel = df_results.loc[0]
    print(setmodel['Model명'])
    joblib.dump(setmodel, os.path.join(MODEL_DIR, f'binary_{target}.pkl'))
    return fig, df_results[['Model명', 'Accuracy', 'Precision', 'Recall', 'F1-Score']]

'''
binary_model(df_all, 'Depo_THK')
binary_model(df_all, 'Particle')
'''


def _load_or_train(df, kind, target):
    """[수정] pkl 이 없으면(5·6번 메뉴를 먼저 안 눌렀으면) 자동으로 학습 후 로드"""
    path = os.path.join(MODEL_DIR, f'{kind}_{target}.pkl')
    if not os.path.exists(path):
        (binary_model if kind == 'binary' else linear_model)(df, target)
        plt.close('all')
    return joblib.load(path)


def _importance(model, feature_cols):
    """[수정] LogisticRegression/KNN 은 feature_importances_ 가 없어 에러 → 대체 처리"""
    if hasattr(model, 'feature_importances_'):
        imp = model.feature_importances_
    elif hasattr(model, 'coef_'):
        imp = np.abs(np.ravel(model.coef_))       # 선형 모델은 |계수|
    else:
        imp = np.full(len(feature_cols), np.nan)  # KNN : 중요도 없음
    return (pd.DataFrame({'Feature': feature_cols, 'Importance': imp})
            .sort_values(by='Importance', ascending=False).reset_index(drop=True))


def binary_predict(df, target):
    results = _load_or_train(df, 'binary', target)   # 가장 성능 좋은 모델 사용
    model = results['model']
    scaler = results['scaler']
    name = results['Model명']
    feature_cols = results["feature_cols"]           # 학습 시 기준 columns

    importance_df = _importance(model, feature_cols)
    print(importance_df)

    y = df[target + "_y"]
    X_scaled = scaler.transform(make_features(df, feature_cols))
    y_pred = model.predict(X_scaled)

    df_anormal = df[(y_pred == 1)]                   # 0: 우량, 1: 불량
    cm = confusion_matrix(y, y_pred, labels=[0, 1])
    cm = pd.DataFrame(cm, index=['실제 정상', '실제 불량'], columns=['예측 정상', '예측 불량'])
    print(cm, "===========")
    # [수정] return 이 주석 처리되어 있어 app3.py 7번 메뉴에서 에러 발생했음
    return name, cm, df_anormal, importance_df

'''
binary_predict(df_all, 'Depo_THK')
'''

# %%
def linear_model(df, target):
    models = {
        # 1. 기본 선형 회귀 (규제 없음, 기준점)
        "LinearRegression": LinearRegression(),
        # 2. L2 규제 : 계수 크기를 줄여 과적합 방지
        "Ridge(L2)": Ridge(alpha=10.0),
        # 3. L1 규제 : 불필요한 피처 가중치를 0 으로 (자동 변수 선택)
        "Lasso(L1)": Lasso(alpha=1.0),
        # 4. L1 + L2 혼합
        "ElasticNet": ElasticNet(alpha=1.0, l1_ratio=0.5),
        # 5. 배깅 앙상블 회귀
        "RandomForestRegressor": RandomForestRegressor(n_estimators=100, max_depth=6,
                                                       min_samples_leaf=5, random_state=42),
        # [추가] 깊이 제한 없는 RF : max_depth=6 보다 R2 가 크게 높음 (비교용)
        "RandomForest(deep)": RandomForestRegressor(n_estimators=200, min_samples_leaf=2,
                                                    random_state=42, n_jobs=-1),
    }
    # 6, 7. 부스팅 앙상블 회귀
    if HAS_XGB:
        models["XGBoost"] = XGBRegressor(n_estimators=100, learning_rate=0.05,
                                         max_depth=4, random_state=42)
    if HAS_LGBM:
        models["LightGBM"] = LGBMRegressor(n_estimators=100, learning_rate=0.05, num_leaves=15,
                                           min_child_samples=10, verbosity=-1, random_state=42)

    y = df[target]
    # [수정] 누수 컬럼(EDGE CENTER 포함)·식별자 제거 + 범주형 원-핫
    X = make_features(df)
    feature_cols = X.columns.tolist()

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    results = []
    for name, model in models.items():
        model.fit(X_train_scaled, y_train)
        y_pred = model.predict(X_test_scaled)
        results.append({
            "Model명": name, "model": model, "scaler": scaler,
            "MAE": mean_absolute_error(y_test, y_pred),          # 평균 절대 오차
            "RMSE": np.sqrt(mean_squared_error(y_test, y_pred)), # 평균 제곱근 오차
            "R2 Score": r2_score(y_test, y_pred),                # 결정 계수
            "y_test": y_test, "y_pred": y_pred,
            "feature_cols": feature_cols})

    df_results = pd.DataFrame(results).sort_values(by='R2 Score', ascending=False)
    df_results = df_results.reset_index(drop=True)

    n = len(df_results)
    fig = plt.figure(figsize=(10, 3.3 * ((n + 2) // 3)))
    for row in range(n):
        plt.subplot((n + 2) // 3, 3, row + 1)
        rows = df_results.iloc[row]
        plt.scatter(x=rows['y_test'], y=rows['y_pred'], alpha=0.5, s=6)
        line_coords = [y_test.min(), y_test.max()]
        plt.plot(line_coords, line_coords, color='red', linestyle='--', lw=2, label='Perfect')
        plt.xlabel('Actual (y_test)')
        plt.ylabel('Predicted (y_pred)')
        plt.title(f"{target}:{rows['Model명']}[{rows['R2 Score']:.4f}]", fontsize=9)
        plt.legend(fontsize=7)
        plt.grid(True)
    plt.tight_layout()

    print(df_results[['Model명', 'MAE', 'RMSE', 'R2 Score']])
    setmodel = df_results.loc[0]
    print(setmodel['Model명'])
    joblib.dump(setmodel, os.path.join(MODEL_DIR, f'linear_{target}.pkl'))
    return fig, df_results[['Model명', 'MAE', 'RMSE', 'R2 Score']]

'''
linear_model(df_all, 'Depo_THK')
linear_model(df_all, 'Particle')
'''

# %%
def vm_predict(df, target):
    """[추가] 저장된 회귀(VM) 모델로 예측값만 반환 → 실시간 FDC 에서 '계측 전 예측값' 감시용"""
    results = _load_or_train(df, 'linear', target)
    X_scaled = results['scaler'].transform(make_features(df, results['feature_cols']))
    return results['model'].predict(X_scaled)


def linear_predict(df, target, sigma):
    """VM 예측값 vs 실제값의 잔차가 평균 ± sigma*표준편차 를 벗어나면 이상치
       → '이 공정 조건이면 이 정도 두께가 나와야 하는데 실제는 다르다' = 설비 이상 의심"""
    results = _load_or_train(df, 'linear', target)
    model = results['model']
    scaler = results['scaler']
    feature_cols = results["feature_cols"]
    y_true = df[target]

    X_scaled = scaler.transform(make_features(df, feature_cols))
    y_pred = model.predict(X_scaled)

    residuals = y_true - y_pred
    residual_mean = np.mean(residuals)
    residual_std = np.std(residuals)
    threshold_upper = residual_mean + (sigma * residual_std)
    threshold_lower = residual_mean - (sigma * residual_std)
    print(threshold_upper, threshold_lower)

    # [수정] 원본은 Is_Outlier=1 이 '정상'이라 이름과 반대였음 → 1 = 이상치 로 통일
    is_outlier = (residuals > threshold_upper) | (residuals < threshold_lower)

    df_result = pd.DataFrame({
        'Actual': y_true,
        'Predicted': y_pred,
        'Residual': residuals,
        'Is_Outlier': is_outlier.astype(int)})
    # [수정] feature_cols.append(target) 로 저장 리스트를 직접 바꾸던 부분 제거
    show_cols = ['LOT', 'WF'] + [c for c in df.columns if c in feature_cols]
    df_result = pd.concat([df[show_cols], df_result], axis=1)

    df_anormal = df_result[df_result['Is_Outlier'] == 1]
    return df_anormal

'''
linear_predict(df_all, 'Depo_THK', 1.5)
'''
