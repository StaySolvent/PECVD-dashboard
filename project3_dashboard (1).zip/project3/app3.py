import streamlit as st

import project3_service as ai
from streamlit.web import cli as stcli
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
pd.options.mode.chained_assignment = None
import warnings
import os
import matplotlib.font_manager as fm
warnings.filterwarnings('ignore')
import time
import requests

# pip install scikit-learn xgboost lightgbm seaborn streamlit
#   실행 : streamlit run app3.py   (또는 Spyder 에서 이 파일 실행 → 아래 __main__ 이 자동 실행)
#   [수정] 표시가 원본 수업 코드에서 고친 부분

# Streamlit Cloud(Linux) 환경 나눔고딕 폰트 파일 경로
nanum_path = '/usr/share/fonts/truetype/nanum/NanumGothic.ttf'
if os.path.exists(nanum_path):
    fm.fontManager.addfont(nanum_path)
    plt.rc('font', family='NanumGothic')
else:
    try:
        plt.rc('font', family='Malgun Gothic')  # Windows
    except Exception:
        plt.rc('font', family='AppleGothic')    # Mac
plt.rcParams['axes.unicode_minus'] = False


st.set_page_config(page_title="대시보드", layout="wide")


@st.cache_data
def get_csv_dataset():
    df = ai.load_csv()
    df_number = df.select_dtypes(include=['number'])
    return df, df_number

df_ai, df_number = get_csv_dataset()


@st.cache_data
def get_vm_series(target):
    """[추가] VM(회귀) 모델의 전체 웨이퍼 예측값 (실시간 FDC '계측 전 예측값' 모드용)"""
    return pd.Series(ai.vm_predict(df_ai, target), index=df_ai.index)


def get_webhook_url():
    """[수정] 웹훅 주소를 코드에 직접 쓰면 GitHub 공개 시 누구나 메시지를 보낼 수 있음
       → Streamlit secrets(.streamlit/secrets.toml) 또는 환경변수 DISCORD_WEBHOOK_URL 에서 읽기"""
    try:
        if "DISCORD_WEBHOOK_URL" in st.secrets:
            return st.secrets["DISCORD_WEBHOOK_URL"]
    except Exception:
        pass
    return os.environ.get("DISCORD_WEBHOOK_URL", "")


def send_discord(msg):
    webhook_url = get_webhook_url()
    if not webhook_url:                       # [수정] 주소 없으면 전송 생략 (앱은 계속 동작)
        print("[Discord] 웹훅 미설정 → 전송 생략 :", msg)
        return
    try:
        response = requests.post(webhook_url, json={"content": msg}, timeout=3)
        if response.status_code == 204:
            print("메시지 전송 성공!")
        else:
            print(f"실패 코드: {response.status_code}")
    except Exception as e:                    # [수정] 네트워크 오류로 앱이 죽지 않도록
        print("Discord 전송 실패 :", e)


menus = ["1.AI Data 검색",
         "2. 히스토그램",
         "3. Line Chart",
         "4. Target과 상관계수",
         "5. 분류 모델",
         "6. 회귀 모델",
         "7. 유/불 확인",
         "8. 예상 target 값",
         "9. 실시간 FDC"]


def main():

    menu = st.sidebar.radio("Project3 : 가상 계측(VM) 및 이상 감지(FDC)", menus)

    if menu == menus[0]:
        search_char = st.text_input("1.찾는 문자를 입력하세요 :", placeholder="예) THK, PC, RF ")
        words = df_ai.columns
        cols = [w for w in words if search_char.lower() in w.lower()]
        if not cols:                                       # [수정] 검색 결과 없으면 KeyError
            st.warning("일치하는 컬럼이 없습니다.")
            return
        chk_col = st.radio("2. 컬럼를 선택하세요:", cols, horizontal=True, index=0)
        temp_li = df_ai[chk_col].unique().tolist()
        if len(temp_li) > 20:
            result = f'{temp_li[:20]}... {len(temp_li)}개'
        else:
            result = f'{temp_li}  {len(temp_li)}개'
        st.write(result)
        st.write(df_ai[chk_col].head())
        if pd.api.types.is_numeric_dtype(df_ai[chk_col]):
            # [수정] 통계값을 계산만 하고 화면에 안 보여줬음
            st.dataframe(pd.DataFrame([{'mean': df_ai[chk_col].mean(), 'min': df_ai[chk_col].min(),
                                        'max': df_ai[chk_col].max(), 'std': df_ai[chk_col].std()}]))
        selected_list = st.multiselect("그룹 기준 컬럼을 선택하세요 (예: Chamber, Precursor) ",
                                       [c for c in df_ai.columns if c != chk_col])
        if st.button("함수 실행"):
            if len(selected_list) != 0:
                gsr = df_ai.groupby(selected_list)[chk_col].value_counts()
                st.dataframe(gsr)

        st.title("공정 변수 체크박스 필터링")
        all_features = df_ai.columns.tolist()
        selected_features = []
        cols = st.columns(4)
        for i, feature in enumerate(all_features):
            with cols[i % 4]:
                if st.checkbox(feature, value=False, key=f"chk_{feature}"):
                    selected_features.append(feature)
        st.markdown("---")
        if selected_features:
            st.subheader("📊 선택된 변수 데이터 확인")
            st.dataframe(df_ai[selected_features])
        else:
            st.error("🚨 선택된 변수가 없습니다. 체크박스를 선택해 주세요.")

    elif menu == menus[1]:
        fig = ai.hist_pro(df_number)
        st.pyplot(fig)

    elif menu == menus[2]:
        fig = ai.line_pro(df_number)
        st.pyplot(fig)

    elif menu == menus[3]:
        st.session_state.clear()
        target = st.radio("Target을 선택 하세요:", ['Depo_THK', 'Particle'], horizontal=True, index=0)
        fig, results = ai.corr_pro(df_ai, target)
        st.pyplot(fig)

    elif menu == menus[4]:
        st.session_state.clear()
        target = st.radio("Target을 선택 하세요:", ['Depo_THK', 'Particle'], horizontal=True, index=0)
        head_01 = ["전체 데이터 중 맞게 맞춘 비율", "예측한 불량 중 실제 불량인 비율",
                   "실제 불량 중 모델이 불량으로 맞춘 비율", "정밀도(Precision)와 재현율(Recall)의 조화평균값"]
        head_df = pd.DataFrame([head_01], columns=["Accuracy", "Precision", "Recall", "F1-Score"])
        st.dataframe(head_df)
        with st.spinner("모델 학습 중..."):
            fig, results = ai.binary_model(df_ai, target)
        st.dataframe(results)
        st.pyplot(fig)

    elif menu == menus[5]:
        st.session_state.clear()
        target = st.radio("Target을 선택 하세요:", ['Depo_THK', 'Particle'], horizontal=True, index=0)
        head_01 = ['평균절대오차:<br> 오차(틀린 양)의 절대값을 평균',
                   '평균제곱근오차:<br> 오차를 제곱해서 평균을 낸 뒤, 다시 루트',
                   '모델 예측 비율']
        head_df = pd.DataFrame([head_01], columns=["MAE", "RMSE", "R2 Score"])
        st.markdown('###### ' + head_df.to_html(escape=False, index=False), unsafe_allow_html=True)
        with st.spinner("모델 학습 중..."):
            fig, results = ai.linear_model(df_ai, target)
        get_vm_series.clear()               # [수정] 모델이 새로 저장됐으니 VM 예측 캐시 초기화
        st.dataframe(results)
        st.pyplot(fig)

    elif menu == menus[6]:
        st.session_state.clear()
        target = st.radio("Target을 선택 하세요:", ['Depo_THK', 'Particle'], horizontal=True, index=0)
        # [수정] service 의 binary_predict 가 값을 return 하도록 고침 (원본은 None → 언패킹 에러)
        name, cm, df_anormal, importance_df = ai.binary_predict(df_ai, target)
        st.subheader(f'{name} 불량 : {len(df_anormal)}/{len(df_ai)} -> 불량률 {len(df_anormal)/len(df_ai):.2%}')
        st.dataframe(cm)
        st.dataframe(df_anormal)
        st.dataframe(importance_df)

    elif menu == menus[7]:
        st.session_state.clear()
        target = st.radio("Target을 선택 하세요:", ['Depo_THK', 'Particle'], horizontal=True, index=0)
        t_sigma = st.slider('잔차(실제-예측) mean ± (sigma * std)',
                            max_value=6.0, min_value=0.5, value=1.5, step=0.5)
        df_linear = ai.linear_predict(df_ai, target, t_sigma)
        st.subheader(f'이상 : {len(df_linear)}/{len(df_ai)} -> 비율 {len(df_linear)/len(df_ai):.2%}')
        st.dataframe(df_linear)

    elif menu == menus[8]:
        st.markdown("##### " + menu)

        c1, c2 = st.columns(2)
        with c1:
            target_col = st.radio("Target을 선택 하세요:", ['Depo_THK', 'Particle'],
                                  horizontal=True, index=0)
        with c2:
            # [추가] 실측값(계측 후) 감시 = 기존 방식 / VM 예측값(계측 전) 감시 = 진짜 실시간 FDC
            mode = st.radio("감시 값:", ['실측값 (계측 후)', 'VM 예측값 (계측 전)'],
                            horizontal=True, index=0)

        # 1. 세션 상태 초기화
        defaults = {"run": False, "disabled": True, "stop_name": "Stop", "lot_id": 0,
                    "current_index": 0, "chart_data": None, "errlist": [], "cfg": None}
        for k, v in defaults.items():
            if k not in st.session_state:
                st.session_state[k] = v

        # [수정] 원본은 UCL/LCL 을 처음 한 번만 계산 → Target 을 바꿔도 Depo_THK 기준 그대로였음
        #        Target/감시값이 바뀌면 상태를 리셋하고 기준선을 다시 계산
        cfg = (target_col, mode)
        if st.session_state.cfg != cfg:
            for k, v in defaults.items():
                st.session_state[k] = v if not isinstance(v, list) else []
            st.session_state.cfg = cfg

        t_mean = df_ai[target_col].mean()
        t_std = df_ai[target_col].std()
        ucl, lcl = t_mean + 3 * t_std, t_mean - 3 * t_std
        lots = df_ai["LOT"].unique().tolist()

        if mode.startswith('VM'):
            series_all = get_vm_series(target_col)      # 계측 없이 공정 조건만으로 예측한 값
        else:
            series_all = df_ai[target_col]              # 계측기로 측정한 실제 값

        speed = 0.03

        # 2. 버튼 영역
        col1, col2, col3 = st.columns([1, 1, 1])
        with col1:
            if st.button("차트 그리기 시작"):
                st.session_state.run = True
                st.session_state.current_index = 0
                st.session_state.disabled = True
                st.session_state.stop_name = "Stop"
                st.session_state.chart_data = None
                st.session_state.errlist = []
                st.session_state.lot_id = 0
                st.rerun()
        with col2:
            if st.button(st.session_state.stop_name, type="secondary"):
                if st.session_state.stop_name == "Stop":
                    st.session_state.stop_name = "Restart"
                    st.session_state.run = False
                else:
                    st.session_state.stop_name = "Stop"
                    st.session_state.run = True
                st.rerun()
        with col3:
            if st.button("이상치 확인 → 계속 진행", disabled=st.session_state.disabled, type="primary"):
                st.session_state.disabled = True
                st.session_state.run = True
                st.session_state.current_index += 1     # 다음 웨이퍼부터 진행
                st.rerun()

        st.caption(f"진행 : LOT {min(st.session_state.lot_id + 1, len(lots))}/{len(lots)}  |  "
                   f"Mean {t_mean:.1f}  UCL {ucl:.1f}  LCL {lcl:.1f}")
        chart_placeholder = st.empty()

        def plot_chart(x_data, y_data, feat_mean, ucl, lcl, feat_std, xlen, lot_name,
                       highlight_outlier=False):
            fig, ax = plt.subplots(figsize=(10, 3))
            ax.axhline(y=feat_mean, color="y", linestyle="--", linewidth=1.5)
            ax.axhline(y=ucl, color="r", linestyle="--", linewidth=1.5)
            ax.axhline(y=lcl, color="r", linestyle="--", linewidth=1.5)
            ax.set_xlabel("wafer id")
            ax.set_title(f"{lot_name}  [{target_col} / {mode}]")
            ax.set_ylabel("값 (Value)")
            ax.set_xlim(0, xlen)
            ax.set_ylim(feat_mean - (feat_std * 5), feat_mean + (feat_std * 5))
            ax.grid(True, linestyle="--", alpha=0.5)
            ax.plot(x_data, y_data, color="#1f77b4", linewidth=0.8, marker="o",
                    mfc="#ff7f0e", mec="#ff7f0e", markersize=2)
            if highlight_outlier:
                ax.plot(x_data[-1], y_data[-1], marker="o", markersize=8, mfc="red", mec="red")
            return fig

        # 4. 실시간 실행 상태 처리
        if st.session_state.run:
            lot_name = lots[st.session_state.lot_id]
            df_t = df_ai[df_ai['LOT'] == lot_name]
            xlen = len(df_t)
            feat_list = series_all.loc[df_t.index].tolist()

            for i in range(st.session_state.current_index, xlen):
                st.session_state.current_index = i
                x_data = list(range(i + 1))
                y_data = feat_list[: i + 1]
                last_value = y_data[-1]
                is_outlier = (last_value > ucl) or (last_value < lcl)

                st.session_state.chart_data = {"x_data": x_data, "y_data": y_data, "xlen": xlen,
                                               "lot_name": lot_name, "is_outlier": is_outlier}
                fig = plot_chart(x_data, y_data, t_mean, ucl, lcl, t_std, xlen, lot_name, is_outlier)
                chart_placeholder.pyplot(fig)
                plt.close(fig)

                # 이상치 탐지 시 멈춤 + Discord 알림 (= 설비 인터락 신호)
                if is_outlier:
                    row = df_t.iloc[i]
                    rec = row.to_dict()
                    rec['감시값'] = round(last_value, 1)
                    st.session_state.errlist.append(rec)
                    # [수정] 행 전체 리스트 대신 사람이 읽기 쉬운 알람 메시지
                    send_discord(f"🚨 [FDC 인터락] {lot_name} / WF {row['WF']} / Chamber {row['Chamber']}"
                                 f" | {target_col}({mode}) = {last_value:.1f}"
                                 f" (UCL {ucl:.1f}, LCL {lcl:.1f})")
                    st.session_state.run = False
                    st.session_state.disabled = False
                    st.rerun()

                time.sleep(speed)

            # 1개 LOT 완료 처리
            if st.session_state.run:
                st.session_state.lot_id += 1
                st.session_state.current_index = 0
                if st.session_state.lot_id < len(lots):
                    st.rerun()
                else:
                    st.session_state.run = False
                    st.success("전체 LOT 모니터링 완료")

        # 5. 멈춤 상태(이상치 발생 포함) 시 기존 차트 유지
        elif st.session_state.chart_data is not None:
            cd = st.session_state.chart_data
            fig = plot_chart(cd["x_data"], cd["y_data"], t_mean, ucl, lcl, t_std,
                             cd["xlen"], cd["lot_name"], cd["is_outlier"])
            chart_placeholder.pyplot(fig)
            plt.close(fig)
            if cd["is_outlier"]:
                st.error("이상치 발생 → 설비 정지(인터락). 확인 후 '계속 진행' 버튼을 누르세요.")

        if len(st.session_state.errlist) > 0:
            err_df = pd.DataFrame(st.session_state.errlist)
            st.subheader(f'불량 row 수 {len(err_df)}')
            st.dataframe(err_df)


#   streamlit run app3.py

if __name__ == "__main__":
    # 현재 프로세스가 streamlit 환경 내에서 실행 중인지 확인
    if st.runtime.exists():
        main()
    else:
        # streamlit 환경이 아니면, 스스로를 streamlit으로 실행 (Spyder 에서 실행 가능)
        sys.argv = ["streamlit", "run", sys.argv[0]]
        sys.exit(stcli.main())
