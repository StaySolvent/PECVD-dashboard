# Project3 : PECVD 가상 계측(VM) · 이상 감지(FDC) 대시보드

## 폴더 구조
```
project3/
├─ app3.py                 # Streamlit 대시보드 (화면)
├─ project3_service.py     # 데이터 처리 · 모델 학습/예측 함수 (백엔드)
├─ data/semi_process_data2.csv
├─ model/                  # 학습된 모델(pkl) 자동 생성 위치
├─ requirements.txt        # 파이썬 패키지 목록 (Streamlit Cloud 용)
├─ packages.txt            # 리눅스 한글 폰트 (Streamlit Cloud 용)
└─ .streamlit/secrets.toml.example   # 디스코드 웹훅 주소 설정 예시
```

## 실행 방법 A : Streamlit Cloud (PC 설치 불필요)
1. GitHub 에 새 저장소를 만들고 이 폴더의 파일을 모두 업로드 (Add file → Upload files)
2. https://share.streamlit.io → GitHub 로그인 → Create app
3. Repository 선택, Main file path = `app3.py` → Deploy
4. (선택) 앱 Settings → Secrets 에 `DISCORD_WEBHOOK_URL = "..."` 입력 → 이상치 발생 시 디스코드 알림

## 실행 방법 B : 내 PC (Anaconda/Miniconda 환경)
```
pip install -r requirements.txt
streamlit run app3.py
```
Spyder 에서 app3.py 를 실행해도 자동으로 streamlit 이 켜집니다.

## 메뉴 사용 순서 (권장)
2·3·4 (EDA) → 5 분류 모델 학습 → 6 회귀 모델 학습 → 7 유/불 확인 → 8 예상 target 값 → 9 실시간 FDC
(5·6을 건너뛰고 7·8·9 를 눌러도 모델이 없으면 자동으로 학습합니다)
